/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arbolDecision;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author CarlosPallares
 */
public class nodo {
    
    public int padre;
    public int numero;
    public String hijo;
    public String info;
    public nodo hijoIz;
    public nodo hijoDr;
    public String lado;

    public nodo(int padre, int numero,String lado, String info) {
        this.padre = padre;
        this.numero = numero;
        this.info = info;
        this.lado=lado;
       
    }

 

    public String getHijo() {
        return hijo;
    }

    public void setHijo(String hijo) {
        this.hijo = hijo;
    }

    

    public int getPadre() {
        return padre;
    }

    public void setPadre(int padre) {
        this.padre = padre;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public nodo getHijoIz() {
        return hijoIz;
    }

    public void setHijoIz(nodo hijoIz) {
        this.hijoIz = hijoIz;
    }

    public nodo getHijoDr() {
        return hijoDr;
    }

    public void setHijoDr(nodo hijoDr) {
        this.hijoDr = hijoDr;
    }

    
    
    
   
    
    
    
}
